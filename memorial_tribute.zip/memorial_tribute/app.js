document.getElementById('tributeForm').addEventListener('submit', function(event) {
    var fullName = document.getElementById('full_name').value;
    var dob = document.getElementById('dob').value;
    var dod = document.getElementById('dod').value;
    var message = document.getElementById('message').value;
    var submittedBy = document.getElementById('submitted_by').value;

    if (!fullName || !dob || !dod || !message || !submittedBy) {
        alert('All fields are required.');
        event.preventDefault();
    }
});

document.querySelector('.nav-link').addEventListener('click', function(){
    console.log('Navigating to view tributes');
});
