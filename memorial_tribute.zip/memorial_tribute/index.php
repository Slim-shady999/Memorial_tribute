<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Memorial Tribute</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
    <div class="navbar">
        <h1 class="heading">Memorial Tribute</h1>
        <a href="view_obituaries.php" class="nav-link">Browse Tributes</a>
    </div>
    <div class="form-container">
        <form id="tributeForm" action="submit_obituary.php" method="post">
            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name"><br>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob"><br>

            <label for="dod">Date of Passing:</label>
            <input type="date" id="dod" name="dod"><br>

            <label for="message">Tribute Message:</label>
            <textarea id="message" name="message"></textarea><br>

            <label for="submitted_by">Submitted By:</label>
            <input type="text" id="submitted_by" name="submitted_by"><br>

            <button type="submit">Submit Tribute</button>
        </form>
    </div>
</body>
</html>
