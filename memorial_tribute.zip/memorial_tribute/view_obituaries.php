<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "memorial_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM tributes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Full Name</th><th>Date of Birth</th><th>Date of Passing</th><th>Message</th><th>Submitted By</th><th>Submission Date</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["full_name"] . "</td>";
        echo "<td>" . $row["dob"] . "</td>";
        echo "<td>" . $row["dod"] . "</td>";
        echo "<td>" . $row["message"] . "</td>";
        echo "<td>" . $row["submitted_by"] . "</td>";
        echo "<td>" . $row["submission_date"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No tributes found";
}

$conn->close();
?>
