<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "memorial_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$full_name = $_POST['full_name'];
$dob = $_POST['dob'];
$dod = $_POST['dod'];
$message = $_POST['message'];
$submitted_by = $_POST['submitted_by'];

$sql = "INSERT INTO tributes (full_name, dob, dod, message, submitted_by) VALUES ('$full_name', '$dob', '$dod', '$message', '$submitted_by')";

if ($conn->query($sql) === TRUE) {
    echo "Tribute submitted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
